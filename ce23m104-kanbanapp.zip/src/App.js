import React, { useState, useEffect } from 'react';
import Header from './Header';
import Board from './Board';
import './App.css';

function App() {
  const [tickets, setTickets] = useState([]);
  const [groupBy, setGroupBy] = useState('status');  // Default group by status
  const [sortBy, setSortBy] = useState('title');     // Default sort by title
  
  // Fetch data from the API
  useEffect(() => {
    fetch('https://api.quicksell.co/v1/internal/frontend-assignment')
      .then(response => response.json())
      .then(data => setTickets(data.tickets))  // API sends tickets as data.tickets
      .catch(error => console.error('Error:', error));
  }, []);

  return (
    <div>
      {/* Header component controls sorting and grouping */}
      <Header setGroupBy={setGroupBy} setSortBy={setSortBy} />
      
      {/* Pass tickets, groupBy and sortBy props to Board */}
      <Board tickets={tickets} groupBy={groupBy} sortBy={sortBy} />
    </div>
  );
}

export default App;