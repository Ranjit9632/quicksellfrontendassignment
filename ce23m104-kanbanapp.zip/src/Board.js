import React from 'react';
import Ticket from './Ticket';
import './Board.css';  // Import the CSS file here

function Board({ tickets, groupBy, sortBy }) {
  
  const groupTickets = (tickets) => {
    switch (groupBy) {
      case 'status':
        return groupByField(tickets, 'status');
      case 'user':
        return groupByField(tickets, 'assignee');
      case 'priority':
        return groupByField(tickets, 'priority');
      default:
        return { 'All': tickets };
    }
  };

  const groupByField = (items, field) => {
    return items.reduce((groups, item) => {
      const groupKey = item[field] || 'Uncategorized';
      if (!groups[groupKey]) groups[groupKey] = [];
      groups[groupKey].push(item);
      return groups;
    }, {});
  };

  const sortTickets = (groupedTickets) => {
    const sortByPriority = (a, b) => b.priority - a.priority;
    const sortByTitle = (a, b) => a.title.localeCompare(b.title);

    for (const group in groupedTickets) {
      groupedTickets[group].sort(sortBy === 'priority' ? sortByPriority : sortByTitle);
    }

    return groupedTickets;
  };

  const groupedTickets = groupTickets(tickets);
  const sortedGroupedTickets = sortTickets(groupedTickets);

  return (
    <div className="kanban-board">
      {Object.keys(sortedGroupedTickets).map((group) => (
        <div key={group} className="kanban-column">
          <h2>{group}</h2>
          {sortedGroupedTickets[group].map((ticket) => (
            <Ticket key={ticket.id} ticket={ticket} />
          ))}
        </div>
      ))}
    </div>
  );
}

export default Board;
