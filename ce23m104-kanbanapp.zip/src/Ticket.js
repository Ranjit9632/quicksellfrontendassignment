import React from 'react';
import './Ticket.css';
import UrgentIcon from './assets/icons/SVG - Urgent Priority colour.svg';
import HighIcon from './assets/icons/Img - High Priority.svg';
import MediumIcon from './assets/icons/Img - Medium Priority.svg';
import LowIcon from './assets/icons/Img - Low Priority.svg';
import NoPriorityIcon from './assets/icons/No-priority.svg';
import threeDotsIcon from './assets/icons/3 dot menu.svg';

function Ticket({ ticket }) {
  const priorityIcons = {
    4: UrgentIcon,
    3: HighIcon,
    2: MediumIcon,
    1: LowIcon,
    0: NoPriorityIcon,
  };

  return (
    <div className="ticket">
      <div className="ticket-header">
        <span>{ticket.title}</span>
        <img src={threeDotsIcon} alt="Menu" className="three-dots" />
      </div>
      <div className="ticket-body">
        <p>{ticket.description}</p>
        <img src={priorityIcons[ticket.priority]} alt="Priority" className="priority-icon" />
      </div>
    </div>
  );
}

export default Ticket;
