import React, { useState } from 'react';
import './Header.css';

const Header = ({ setGroupBy, setSortBy }) => {
  const [isDisplayMenuOpen, setIsDisplayMenuOpen] = useState(false);

  // Toggle the visibility of the display menu
  const toggleDisplayMenu = () => {
    setIsDisplayMenuOpen(!isDisplayMenuOpen);
  };

  return (
    <div className="header">
      <button className="display-button" onClick={toggleDisplayMenu}>
        Display Options
      </button>
      
      {isDisplayMenuOpen && (
        <div className="display-menu">
          <div>
            <label>Grouping</label>
            <select onChange={(e) => setGroupBy(e.target.value)}>
              <option value="status">Status</option>
              <option value="user">User</option>
              <option value="priority">Priority</option>
            </select>
          </div>

          <div>
            <label>Ordering</label>
            <select onChange={(e) => setSortBy(e.target.value)}>
              <option value="priority">Priority</option>
              <option value="title">Title</option>
            </select>
          </div>
        </div>
      )}
    </div>
  );
};

export default Header;
